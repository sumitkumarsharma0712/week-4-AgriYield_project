# Adding a new agribusiness scenario

The framework is scenario-agnostic: everything specific to a problem lives in one
`ScenarioConfig` (see `src/agri_forecast/config.py`). No pipeline code changes.

## 1. Prepare a tidy panel table

One row per *entity x time period* with a complete, regular time grid:

| Requirement | Example (crop yield) | Example (poultry egg output) |
|---|---|---|
| Ordinal integer time column | `year` | `week_idx` |
| Entity columns (one series each) | `region`, `crop` | `farm_id` |
| Numeric target | `yield_t_ha` | `eggs_per_hen_week` |
| Drivers known at forecast time | weather, soil, inputs | temperature, feed, flock age, vaccination |

## 2. Write the config

```python
from agri_forecast.config import ScenarioConfig

POULTRY = ScenarioConfig(
    name="poultry_eggs", title="Weekly egg output per farm",
    target="eggs_per_hen_week", target_unit="eggs", time_col="week_idx",
    entity_cols=["farm_id"], group_col="district", segment_col="strain",
    categorical=["strain", "district"],
    numeric=["temp_c", "feed_kg", "flock_age_wk", "mortality_rate"],
    feature_groups={"climate": ["temp_c"], "nutrition": ["feed_kg"],
                    "flock": ["flock_age_wk", "mortality_rate"],
                    "farm_profile": ["strain", "district"]},
    lags=[1, 2, 4], rolling_windows=[4, 12], cyclical={"week_of_year": 52},
    test_periods=26, cv_folds=4, cv_block=13)
```

Rules of thumb: `lags` should include 1; `test_periods` should span at least one full
seasonal cycle when the target is seasonal; every numeric/categorical feature must
belong to exactly one `feature_groups` entry (the code asserts this).

## 3. Run

```bash
python main.py --scenario poultry_eggs --data my_poultry_table.csv
```

(Register the config in `scenarios.py` first, or call `run_scenario(cfg, df, "results")`
directly from Python.)

## 4. What you get without extra work

Leakage-safe lag/rolling/anomaly features, temporal hold-out + rolling-origin CV,
four tuned model families + ensemble, baselines and skill score, bootstrap CIs,
segment metrics, 90 % conformal intervals, group importance, ablation, spatial
(group-wise) CV, PSI drift table, noise and missing-data stress tests, figures and a
persisted model.
