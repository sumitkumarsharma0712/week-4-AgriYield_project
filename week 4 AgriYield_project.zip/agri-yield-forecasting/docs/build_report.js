const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, Header, Footer,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
  TabStopType, TabStopPosition,
} = require("docx");

const D = JSON.parse(fs.readFileSync(path.join(__dirname, "report_data.json"), "utf8"));
const OUT = path.join(__dirname, "..", "outputs");
const FIG = path.join(__dirname, "figures");
const PRIMARY = "0B4F6C", LIGHT = "E8F1F5", ACCENT = "D55E00", GREY = "5B6770", BORDER = "BFC9D0", ZEBRA = "F5F8FA";
const PAGE_W = 11906, PAGE_H = 16838, MARGIN = 1247, CW = PAGE_W - 2 * MARGIN; // 9412 content width (DXA)

let figN = 0, tabN = 0;

// ---------- helpers ----------
const run = (t, o = {}) => new TextRun({ text: t, ...o });
function rich(text, base = {}) {          // **bold** inline markup
  return text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map(s =>
    s.startsWith("**") ? run(s.slice(2, -2), { ...base, bold: true }) : run(s, base));
}
const P = (text, o = {}) => new Paragraph({ children: rich(text, o.run || {}), spacing: { after: 120, line: 288 }, alignment: o.align || AlignmentType.JUSTIFIED, ...o.para });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)] });
const H1p = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)], pageBreakBefore: true });
const H1n = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [run(t)] });
const H3 = t => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [run(t)] });
const B = (t, lvl = 0) => new Paragraph({ numbering: { reference: "bullets", level: lvl }, children: rich(t), spacing: { after: 70, line: 276 } });
const N = (t, ref = "nums") => new Paragraph({ numbering: { reference: ref, level: 0 }, children: rich(t), spacing: { after: 70, line: 276 } });
const spacer = (n = 120) => new Paragraph({ children: [], spacing: { after: n } });

const border = { style: BorderStyle.SINGLE, size: 4, color: BORDER };
const borders = { top: border, bottom: border, left: border, right: border };

function cell(text, w, o = {}) {
  const paras = String(text).split("\n").map(line => new Paragraph({
    alignment: o.align || AlignmentType.LEFT, spacing: { after: 30, line: 252 },
    children: rich(line, { size: o.size || 18, color: o.color, bold: o.bold }),
  }));
  return new TableCell({
    width: { size: w, type: WidthType.DXA }, borders, verticalAlign: "center",
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 90, right: 90 }, children: paras, columnSpan: o.span,
  });
}
function table(headers, rows, widths, o = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const al = o.align || widths.map(() => AlignmentType.LEFT);
  const hdr = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => cell(h, widths[i], { fill: PRIMARY, color: "FFFFFF", bold: true, align: al[i] === AlignmentType.LEFT ? AlignmentType.LEFT : AlignmentType.CENTER, size: o.size })) });
  const body = rows.map((r, ri) => new TableRow({
    cantSplit: true,
    children: r.map((c, i) => cell(c, widths[i], { align: al[i], fill: (o.hi && o.hi.includes(ri)) ? "FFF2CC" : (ri % 2 ? ZEBRA : undefined), bold: (i === 0 && o.boldFirst), size: o.size })),
  }));
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, rows: [hdr, ...body] });
}
const caption = (kind, text) => {
  const n = kind === "Figure" ? ++figN : ++tabN;
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 200 }, keepNext: kind === "Table" ? false : false,
    children: [run(`${kind} ${n}. `, { bold: true, size: 18, color: PRIMARY }), run(text, { italics: true, size: 18, color: GREY })] });
};
const tcap = text => { const n = ++tabN; return new Paragraph({ spacing: { before: 160, after: 80 }, keepNext: true, children: [run(`Table ${n}. `, { bold: true, size: 18, color: PRIMARY }), run(text, { italics: true, size: 18, color: GREY })] }); };
function pngSize(p) { const b = fs.readFileSync(p); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }
function fig(file, widthPx, cap, dir = FIG) {
  const p = path.join(dir, file); const [w, h] = pngSize(p);
  return [new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 40 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(p), transformation: { width: widthPx, height: Math.round(widthPx * h / w) },
      altText: { title: cap, description: cap, name: file } })] }), caption("Figure", cap)];
}
const cropFig = (f, w, c) => fig(f, w, c, path.join(OUT, "crop_yield", "figures"));
const dairyFig = (f, w, c) => fig(f, w, c, path.join(OUT, "dairy_milk", "figures"));

function callout(title, lines, fill = LIGHT, bar = PRIMARY) {
  const nb = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
  return new Table({
    width: { size: CW, type: WidthType.DXA }, columnWidths: [CW],
    rows: [new TableRow({ children: [new TableCell({
      width: { size: CW, type: WidthType.DXA }, shading: { fill, type: ShadingType.CLEAR, color: "auto" },
      borders: { top: nb, bottom: nb, right: nb, left: { style: BorderStyle.SINGLE, size: 24, color: bar } },
      margins: { top: 120, bottom: 120, left: 200, right: 160 },
      children: [new Paragraph({ spacing: { after: 80 }, children: [run(title, { bold: true, color: bar, size: 22 })] }),
        ...lines.map(l => new Paragraph({ spacing: { after: 60, line: 276 }, children: rich(l, { size: 20 }) }))],
    })] })],
  });
}
const f2 = (x, d = 2) => Number(x).toFixed(d);
const R = AlignmentType.RIGHT, L = AlignmentType.LEFT, C = AlignmentType.CENTER;

const cy = D.crop_yield.summary, dm = D.dairy_milk.summary;
const cyM = cy.test_metrics, dmM = dm.test_metrics;

// ---------- cover ----------
const cover = [
  spacer(1400),
  new Paragraph({ children: [run("WEEK 4 TASK  |  DATA SCIENCE INTERNSHIP", { bold: true, size: 22, color: ACCENT, characterSpacing: 40 })], spacing: { after: 240 } }),
  new Paragraph({ children: [run("Predictive Modeling Framework", { bold: true, size: 68, color: PRIMARY })], spacing: { after: 120 } }),
  new Paragraph({ children: [run("for Agricultural Yield Forecasting and Agribusiness Performance Metrics", { size: 34, color: "33414A" })], spacing: { after: 360 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: ACCENT, space: 12 } } }),
  new Paragraph({ children: [run("A machine-learning proposal covering rationale, feature selection, model training, validation, reliability and cross-scenario transferability, with a fully reproducible Python implementation (AgriYield).", { size: 24, color: GREY, italics: true })], spacing: { before: 240, after: 1500 } }),
  new Paragraph({ children: [run("Prepared by", { size: 20, color: GREY })] }),
  new Paragraph({ children: [run("Sumit Kumar Sharma", { bold: true, size: 36, color: PRIMARY })] }),
  new Paragraph({ children: [run("Junior Data Scientist Intern  |  Nagpur, Maharashtra, India", { size: 24 })], spacing: { after: 300 } }),
  new Paragraph({ children: [run("Submission date: 26 October 2026", { size: 22, color: GREY })] }),
  new Paragraph({ children: [run("Code: agri-yield-forecasting (Python 3, scikit-learn)", { size: 22, color: GREY })] }),
];

// ---------- contents (static) ----------
const toc = [
  ["1", "Executive Summary"], ["2", "Introduction and Rationale"], ["3", "Framework Overview"],
  ["4", "Data Features and Their Selection"], ["5", "Feature Engineering"], ["6", "Model Training Process"],
  ["7", "Machine Learning Algorithms"], ["8", "Performance Evaluation and Reliability"], ["9", "Results of the Reference Implementation"],
  ["10", "Universal Applicability Across Agribusiness Scenarios"], ["11", "Deployment, Monitoring and Governance"],
  ["12", "Limitations and Future Work"], ["13", "Conclusion"], ["", "References"], ["A", "Appendix: Project Structure and Reproduction Steps"],
];
const tocBlock = [
  new Paragraph({ children: [run("Contents", { bold: true, size: 36, color: PRIMARY })], spacing: { after: 240 }, pageBreakBefore: true }),
  ...toc.map(([n, t]) => new Paragraph({ spacing: { after: 110 }, tabStops: [{ type: TabStopType.LEFT, position: 700 }],
    children: [run(n, { bold: true, color: ACCENT, size: 24 }), run("\t" + t, { size: 24 })] })),
];

// ---------- 1 Executive summary ----------
const s1 = [
  H1n("1. Executive Summary"),
  P("Agribusiness decisions such as input purchasing, irrigation scheduling, storage, logistics, crop insurance and credit are made months before a harvest is known. Better forecasts of yield and of related performance metrics let each of these decisions be made with less waste and less risk. This report proposes **AgriYield**, a complete and reusable predictive modelling framework that turns historical weather, soil, crop-management and satellite data into forecasts that come with explicit measures of uncertainty and reliability."),
  P("The framework is organised into eight stages (Figure 1): data acquisition, quality and leakage checks, feature engineering, chronological splitting, model training and tuning, ensemble selection, evaluation and uncertainty quantification, and deployment with monitoring. Each stage is implemented in a tested Python package, so the proposal is not only a design but a working system."),
  callout("Headline results (reference implementation, simulated district-level data)", [
    `**Crop-yield scenario.** ${cy.rows.toLocaleString()} district-crop-year records, ${cy.n_features} candidate features, 3-year hidden test period (2021-2023). The CV-selected ensemble reaches **R² = ${f2(cyM.R2, 3)}**, **RMSE = ${f2(cyM.RMSE)} q/ha** and **MAPE = ${f2(cyM.MAPE, 1)}%**, a **${f2(cy.skill_vs_naive * 100, 0)}% error reduction** versus the naive "same as last year" forecast.`,
    `**Transfer test.** The same code, unchanged apart from a configuration object, forecasts monthly farm-level dairy milk yield with **R² = ${f2(dmM.R2, 3)}**, MAPE = ${f2(dmM.MAPE, 1)}% and a ${f2(dm.skill_vs_naive * 100, 0)}% error reduction over the naive baseline.`,
    `**Reliability.** 90% conformal prediction intervals covered ${f2(cy.interval_coverage_90 * 100, 1)}% (crop) and ${f2(dm.interval_coverage_90 * 100, 1)}% (dairy) of test outcomes; the shortfall in the crop case is traced to a measurable covariate drift (warming and irrigation expansion) and discussed openly in Section 9.`,
  ]),
  spacer(160),
  P("**Important disclosure.** The datasets used to demonstrate the framework are simulated using documented agronomic relationships, because a complete, openly redistributable panel with all required variables is not available. The accuracy figures therefore show that the pipeline works correctly and is leakage-free; they should not be quoted as expected real-world accuracy. The code accepts real data in the same schema without modification."),
  ...fig("pipeline.png", 600, "End-to-end workflow of the proposed predictive modelling framework."),
];

// ---------- 2 Introduction ----------
const s2 = [
  H1p("2. Introduction and Rationale"),
  H2("2.1 Why forecast crop yield?"),
  P("Agriculture is highly exposed to weather and market risk. In the Vidarbha region around Nagpur, rain-fed cotton, soybean and pigeon pea dominate, and the monsoon's timing and distribution can change a district's output substantially from one year to the next. Stakeholders along the value chain need an early, quantified view of the coming season:"),
  B("**Farmers and FPOs:** choose varieties, sowing dates and fertiliser rates; decide when to sell or store."),
  B("**Agribusiness firms and processors:** plan procurement, ginning and crushing capacity, warehousing and transport."),
  B("**Input suppliers:** align seed, fertiliser and agrochemical stock with expected demand."),
  B("**Banks and insurers:** price crop loans and parametric insurance, and detect stress early."),
  B("**Government agencies:** assess food security, MSP procurement and drought relief needs."),
  H2("2.2 Why machine learning rather than traditional methods?"),
  P("Conventional approaches, such as crop-cutting surveys, expert judgement and simple regression on rainfall, are valuable but face limits. Surveys arrive after the season; linear regressions miss the strongly non-linear and interacting effects that govern yield (a given heat spike is harmless after grain filling but damaging at flowering; extra fertiliser helps only when water is sufficient). Machine-learning models, especially tree ensembles, learn these threshold effects and interactions automatically, handle mixed numeric and categorical inputs, tolerate missing values, and scale to many districts, crops and years at once (van Klompenburg et al., 2020; Lobell and Burke, 2010)."),
  H2("2.3 From yield forecasts to resource optimisation"),
  P("A forecast is a means, not an end. The framework is designed so that its outputs feed resource decisions directly:"),
  table(["Decision", "Forecast information used", "Benefit"], [
    ["Fertiliser and input planning", "Expected yield and its drivers (permutation importance)", "Apply nutrients where marginal response is highest; avoid over-application"],
    ["Irrigation prioritisation", "Predicted water-stress sensitivity by district and crop", "Direct scarce water to the highest-return fields"],
    ["Procurement and logistics", "District forecast with 90% interval", "Right-size storage, trucking and working capital; plan for the downside"],
    ["Credit and insurance", "Interval width and early-season anomalies", "Risk-based pricing; faster trigger of relief"],
    ["Crop planning", "Scenario runs on sowing date, variety, irrigation", "Choose crop mix that maximises expected return per unit of water"],
  ], [2300, 3700, 3412], { boldFirst: true }),
  tcap("Decisions that a yield-forecasting framework supports."),
  H2("2.4 Problem formulation"),
  P("The task is formulated as **supervised regression on a panel**: for entity *i* (district-crop, farm) and period *t*, predict the target y(i,t) (yield in quintal/ha, milk in litres/cow/day, and so on) from features observable at the forecast origin. Two design rules are applied throughout. First, **only information available at the forecast origin may be used**; this governs lag construction and the choice of in-season variables such as peak NDVI. Second, **success is defined relative to a naive baseline**; a model is useful only if it beats what a practitioner could do with a spreadsheet."),
];

// ---------- 3 Framework overview ----------
const s3 = [
  H1("3. Framework Overview"),
  P("The workflow in Figure 1 is implemented as a Python package with one module per concern. A single **Scenario** object declares the target, the time column, the entity columns and the feature groups; everything downstream is generic."),
  table(["Module", "Responsibility", "Key design choice"], [
    ["config.py", "Scenario definition (target, time, entity, feature groups, split dates)", "Problem-specific knowledge lives in configuration, not in code"],
    ["data_generator.py", "Agronomy-based simulators; loader for real CSV data", "Real data can replace simulation without code changes"],
    ["features.py", "Lags, rolling means, domain indices", "All history features use strictly earlier periods (no leakage)"],
    ["models.py", "Preprocessing, model zoo, forward-chaining CV, search", "Imputation and scaling live inside the CV pipeline"],
    ["evaluate.py", "Metrics, skill score, conformal intervals, PSI drift", "Reliability is a first-class output, not an afterthought"],
    ["pipeline.py", "Orchestrates all stages and writes reports, figures, model", "One command reproduces every number in this report"],
  ], [2000, 3900, 3512], { boldFirst: true }),
  tcap("Software architecture of the AgriYield framework."),
  P("Three principles guide the framework. **Leakage-free by construction:** lag features are shifted within each entity series, imputers are fitted only on training folds, and the final test period is scored exactly once. **Honest benchmarking:** every model is reported next to three naive baselines. **Uncertainty-aware:** each forecast carries a calibrated interval so decisions can be risk-adjusted."),
];

// ---------- 4 Data features ----------
const s4 = [
  H1("4. Data Features and Their Selection"),
  P("Candidate features were chosen by working backwards from the crop-physiology question \"what limits yield, and what can a decision-maker influence?\". Each group below is retained only if it has a clear causal or predictive rationale and a realistic public or enterprise data source in India."),
  tcap("Feature groups, rationale for inclusion and typical data sources."),
  table(["Group", "Variables", "Why it influences yield", "Typical source"], [
    ["Weather", "Monsoon rainfall (mm), rain days, longest dry spell, mean temperature, maximum temperature at flowering, humidity, solar radiation",
      "Water supply and its distribution drive biomass; heat at flowering sterilises pollen; dry spells cause moisture stress; humidity raises disease pressure; radiation drives photosynthesis",
      "IMD gridded data, NASA POWER, ERA5"],
    ["Soil", "pH, organic carbon, available N, P, K, water-holding capacity",
      "Control nutrient supply and the soil's ability to buffer rainfall variability",
      "Soil Health Card, ICAR-NBSS&LUP"],
    ["Management", "Irrigated fraction, nitrogen applied, seed rate, sowing day-of-year, variety type, pest index",
      "Controllable levers; sowing date sets exposure to heat and rain; hybrids raise the yield ceiling; pests cut realised yield",
      "State agriculture department, KVK records, farm apps"],
    ["Remote sensing", "Peak NDVI",
      "Integrates the combined effect of weather, soil and management on canopy vigour, so it captures what the other variables miss",
      "Sentinel-2, MODIS"],
    ["History", "Yield lag 1, lag 2, 3-period rolling mean, recent change",
      "Persistence of local conditions and the technology trend; strongest single compact proxy for unobserved factors",
      "Directorate of Economics and Statistics, crop-cutting experiments"],
    ["Identity", "District, crop",
      "Absorb stable entity effects (agro-climatic zone, crop potential)", "Master data"],
  ], [1250, 2500, 3662, 2000], { boldFirst: true, size: 17 }),
  H2("4.1 Forecast-origin discipline"),
  P("Each variable is tagged with the date by which it becomes known. Pre-season variables (soil, planned irrigation, seasonal outlooks, lagged yields) support a forecast at sowing; monsoon totals and heat at flowering are available by early-to-mid season; peak NDVI is available shortly before grain filling. The framework therefore supports a **staged forecast**: a model trained with only the features available at each stage, with accuracy improving as the season progresses. In the reference implementation all features are used, which corresponds to the end-of-flowering forecast origin."),
  H2("4.2 Data quality handling"),
  B("**Missing values:** random gaps (3% injected into five variables) are filled by median imputation for numeric and most-frequent imputation for categorical fields, always fitted inside the training fold only."),
  B("**Categorical encoding:** one-hot encoding with unseen categories ignored, so a new district or variety cannot crash a production run."),
  B("**Scaling:** standardisation only for the linear model; tree models are scale-invariant."),
  B("**Outliers:** retained because droughts and floods are the events of greatest decision value; robustness is obtained from tree-based learners and from reporting MAE alongside RMSE."),
  H2("4.3 Exploratory view of the data"),
  ...cropFig("01_target_overview.png", 580, "Mean yield by crop over 2005-2023 (left) and distribution of the target (right) in the reference crop-yield dataset. Drought years (2009, 2012, 2014, 2015, 2018, 2022) appear as common dips across crops."),
  ...cropFig("02_correlation.png", 400, "Pearson correlation of numeric features with yield. Linear correlations are modest because the dominant effect is the crop identity and the relationships are non-linear, motivating non-linear models."),
];

// ---------- 5 Feature engineering ----------
const s5 = [
  H1("5. Feature Engineering"),
  P("Raw variables are transformed into features that express agronomic mechanisms explicitly. This helps especially with small panels, where a model cannot be expected to discover every interaction from data alone."),
  tcap("Engineered features used in the crop-yield scenario."),
  table(["Feature", "Definition", "Rationale"], [
    ["yield_lag1, lag2", "Yield of the same district-crop 1 and 2 seasons earlier", "Persistence of local productivity and technology level"],
    ["yield_roll3", "Mean of the previous 3 seasons (current excluded)", "Smooths one-off shocks; robust level estimate"],
    ["yield_trend", "lag1 minus lag2", "Direction of recent change"],
    ["heat_stress_deg", "max(0, T_max at flowering - 33 C)", "Damage is zero below a threshold and rises above it"],
    ["dryspell_x_heat", "Longest dry spell x heat-stress degrees", "Compound stress is worse than the sum of its parts"],
    ["water_supply_index", "Rainfall x (1 + irrigated fraction) x water-holding / 20", "Effective water available to the crop"],
    ["rain_per_day", "Seasonal rainfall / rain days", "Intensity; high values imply run-off and erosion"],
    ["n_applied_per_soil_n", "Fertiliser N / soil N", "Relative nutrient sufficiency"],
    ["npk_total", "Weighted soil N + P + K", "Overall fertility score"],
    ["gdd_proxy", "max(0, mean temperature - 10) x 120", "Thermal time proxy for crop development"],
  ], [2300, 3700, 3412], { boldFirst: true, size: 17 }),
  P("For the dairy scenario the same mechanism is expressed through the **temperature-humidity index** THI = 0.8T + RH/100 x (T - 14.4) + 46.4, a heat-stress measure widely used in animal science, together with feed totals, concentrate share, lactation-curve shape and cyclical month encoding."),
  H2("5.1 Leakage safeguards"),
  P("History features are built by shifting values within each entity series before any rolling operation, so the value for period *t* never includes the target of period *t*. A unit test asserts this property and another asserts that every cross-validation fold trains strictly on earlier periods than it validates. Rows at the start of each series with no lag are used in training (with median imputation) but excluded from the test score, so the reported accuracy reflects true one-step-ahead forecasting."),
];

// ---------- 6 Training process ----------
const s6 = [
  H1("6. Model Training Process"),
  H2("6.1 Data splitting"),
  P("Yield data are ordered in time and the aim is to predict **future** seasons, so random shuffling would let the model see the future and give an optimistic score. A strictly chronological split is used (Figure 4):"),
  table(["Partition", "Years (crop)", "Months (dairy)", "Purpose"], [
    ["Development", "2005-2020 (1,120 rows)", "1-48 (1,920 rows)", "Training and hyperparameter search via forward-chaining CV"],
    ["Hidden test", "2021-2023 (210 rows)", "49-60 (480 rows)", "Single final, untouched evaluation"],
  ], [1700, 2400, 2100, 3212], { boldFirst: true }),
  tcap("Chronological data partitions."),
  ...fig("split_design.png", 580, "Chronological split and forward-chaining (expanding window) validation. Each fold trains on all earlier years and validates on the next block."),
  H2("6.2 Preprocessing and feature pipeline"),
  P("Imputation, encoding and scaling are wrapped with the model in one scikit-learn Pipeline. During cross-validation the transformers are fitted on the training portion of each fold only, which prevents information from validation years leaking into medians or scaling statistics."),
  H2("6.3 Model selection and hyperparameter tuning"),
  N("**Baselines first:** last-period value, 3-period mean, and entity mean establish the bar to beat.", "steps"),
  N("**Candidate models:** a regularised linear model (interpretable reference) and three non-linear ensembles (Random Forest, Extra Trees, Gradient Boosting).", "steps"),
  N("**Randomised search:** 12 hyperparameter draws per model, scored by negative RMSE across four forward-chaining folds. Random search covers continuous ranges efficiently and is cheaper than a full grid.", "steps"),
  N("**Refit:** the best configuration is refit on the full development set.", "steps"),
  N("**Ensemble:** the two models with the lowest CV error are averaged (simple voting). Averaging models with different inductive biases usually reduces variance.", "steps"),
  N("**Champion selection on CV, not on test:** the model reported as final is chosen by cross-validated error. The test set is never used to choose among models, so the final score is an unbiased estimate.", "steps"),
  tcap("Tuned hyperparameters (crop-yield scenario)."),
  table(["Model", "Selected hyperparameters"], [
    ["Ridge", `alpha = ${f2(cy.best_params.Ridge.alpha, 3)}`],
    ["Random Forest", `max_depth = ${cy.best_params.RandomForest.max_depth ?? "None"}, min_samples_leaf = ${cy.best_params.RandomForest.min_samples_leaf}, max_features = ${f2(cy.best_params.RandomForest.max_features)}, 300 trees`],
    ["Extra Trees", `max_depth = ${cy.best_params.ExtraTrees.max_depth ?? "None"}, min_samples_leaf = ${cy.best_params.ExtraTrees.min_samples_leaf}, max_features = ${f2(cy.best_params.ExtraTrees.max_features)}, 300 trees`],
    ["Gradient Boosting", `learning_rate = ${f2(cy.best_params.GradientBoosting.learning_rate, 3)}, max_iter = ${cy.best_params.GradientBoosting.max_iter}, max_depth = ${cy.best_params.GradientBoosting.max_depth}, min_samples_leaf = ${cy.best_params.GradientBoosting.min_samples_leaf}, L2 = ${f2(cy.best_params.GradientBoosting.l2_regularization, 2)}`],
    ["Ensemble", `Average of ${cy.ensemble_members.join(" and ")}`],
  ], [2400, 7012], { boldFirst: true }),
  ...cropFig("09_cv_folds.png", 430, "Forward-chaining cross-validation RMSE per validation year for each model. Fold-to-fold variation (for example year 2018, a drought year) shows why a single split would be misleading."),
];

// ---------- 7 Algorithms ----------
const s7 = [
  H1("7. Machine Learning Algorithms"),
  P("The framework is intentionally model-agnostic: any estimator that follows the scikit-learn interface can be added to the model zoo. the table below compares the algorithms implemented and those proposed as extensions."),
  tcap("Algorithms: strengths, limitations and role in the framework."),
  table(["Algorithm", "Strengths", "Limitations", "Status"], [
    ["Ridge regression (Hoerl and Kennard, 1970)", "Fast, stable with correlated inputs, fully interpretable coefficients; strong sanity-check model", "Cannot capture thresholds or interactions without manual terms", "Implemented"],
    ["Random Forest (Breiman, 2001)", "Averages many de-correlated deep trees; robust to noise and outliers; little tuning", "Cannot extrapolate beyond training range; larger memory footprint", "Implemented"],
    ["Extra Trees (Geurts et al., 2006)", "Random split thresholds give extra variance reduction and speed", "Slightly higher bias on small data", "Implemented"],
    ["Gradient Boosting (Friedman, 2001)", "Sequentially corrects errors; best accuracy on tabular data; handles missing values natively", "Needs careful regularisation; sensitive to hyperparameters", "Implemented (histogram-based)"],
    ["Voting ensemble", "Reduces variance by combining different model families", "Less interpretable than a single model", "Implemented"],
    ["XGBoost / LightGBM (Chen and Guestrin, 2016; Ke et al., 2017)", "Highly optimised boosting with rich regularisation; GPU support", "Extra dependency; benefit over histogram boosting often modest on small panels", "Drop-in extension"],
    ["Mixed-effects / hierarchical Bayesian models", "Partial pooling gives sensible estimates for districts with few records; native uncertainty", "More modelling effort; slower to fit", "Proposed"],
    ["LSTM / Temporal Fusion Transformer", "Learn from daily weather sequences and long histories", "Need much more data; harder to explain", "Proposed when daily data available"],
    ["CNN / vision transformer on satellite imagery", "Extract crop-health patterns directly from pixels", "Heavy compute and labelled data needs", "Proposed for field-level scale"],
    ["Quantile regression forests / gradient boosting", "Native predictive intervals", "Intervals can be miscalibrated without conformal correction", "Proposed (conformal used instead)"],
  ], [2200, 3100, 2800, 1312], { boldFirst: true, size: 16 }),
  H2("7.1 Why tree ensembles are the primary choice"),
  B("Yield responses are **threshold-like and interactive**: trees represent them naturally."),
  B("Inputs are **mixed and partly missing**; trees need no scaling and boosting handles gaps."),
  B("Panels are **small to medium** (hundreds to thousands of rows), where gradient boosting and forests routinely beat deep networks."),
  B("They provide **built-in or model-agnostic explanations**, which agribusiness stakeholders require before acting."),
  H2("7.2 Known weakness: extrapolation"),
  P("Tree models predict within the range of target values seen in training. When yields trend upward over time (new hybrids, more irrigation), forecasts for new years can lag behind. The framework addresses this with the lag and trend features, and recommends two further remedies when needed: modelling the **ratio to the entity's recent mean** instead of the raw yield, or fitting a linear trend and letting the ensemble model the residual. Section 9 shows this effect empirically."),
];

// ---------- 8 Evaluation ----------
const s8 = [
  H1("8. Performance Evaluation and Reliability"),
  H2("8.1 Accuracy metrics"),
  table(["Metric", "Definition", "Why it is used"], [
    ["RMSE", "Square root of mean squared error", "Same units as target; penalises large misses (drought years)"],
    ["MAE", "Mean absolute error", "Typical error size; less affected by outliers than RMSE"],
    ["MAPE / sMAPE", "Percentage error (symmetric variant)", "Comparable across crops with different yield levels (Hyndman and Koehler, 2006)"],
    ["R²", "Share of variance explained", "Intuitive overall fit; reported with care since pooling crops inflates it"],
    ["Bias", "Mean(prediction - actual)", "Detects systematic over- or under-forecasting"],
    ["Skill score", "1 - RMSE(model) / RMSE(naive)", "Direct measure of value added over a naive forecast"],
  ], [1700, 3300, 4412], { boldFirst: true }),
  tcap("Evaluation metrics."),
  H2("8.2 Reliability toolkit"),
  table(["Check", "What it answers", "Implementation"], [
    ["Hidden chronological test", "Will it work on future seasons?", "Years 2021-2023 scored once after model selection"],
    ["Forward-chaining CV", "Is performance stable across years?", "4 expanding-window folds; per-fold RMSE reported"],
    ["Naive baselines and skill score", "Is the model better than a simple rule?", "Last period, 3-period mean, entity mean"],
    ["Error slicing", "Where does it fail?", "Metrics by crop, district and year"],
    ["Prediction intervals", "How uncertain is each forecast?", "Split-conformal 90% intervals from out-of-fold residuals (Vovk et al., 2005)"],
    ["Permutation importance", "What drives predictions?", "Increase in test RMSE when a feature is shuffled (Fisher et al., 2019)"],
    ["Feature-group ablation", "Which data sources are worth collecting?", "Refit without each group; compare RMSE"],
    ["Leave-district-out CV", "Does it generalise to unseen locations?", "5-fold GroupKFold by district (or farm)"],
    ["Drift monitoring", "Have inputs shifted since training?", "Population Stability Index (PSI) per feature"],
    ["Unit tests", "Is the code correct?", "Seven tests: schema, no leakage, no look-ahead, metrics, conformal coverage, PSI"],
  ], [2400, 2900, 4112], { boldFirst: true, size: 17 }),
  tcap("Reliability checks built into the framework."),
  H2("8.3 Conformal prediction intervals"),
  P("Point forecasts alone are risky in agriculture. The framework wraps the champion model in a **split-conformal interval**: absolute out-of-fold residuals from the validation folds are collected, their 90th percentile gives a half-width q, and the interval for a new forecast is the prediction plus or minus q. This is distribution-free and, when future errors resemble past errors, achieves the nominal coverage. Coverage is then **measured** on the hidden test set instead of being assumed."),
  H2("8.4 Interpreting PSI"),
  P("PSI below 0.10 indicates a stable input, 0.10-0.25 a moderate shift and above 0.25 a major shift that should trigger investigation or retraining. Agricultural inputs shift for real reasons (climate trend, technology adoption), so PSI is used as an early-warning signal for model refresh."),
];

// ---------- 9 Results ----------
const mrows = D.crop_yield.models.map(m => [m[0], f2(m[1]), f2(m[2]), f2(m[3], 1), f2(m[4], 3), f2(m[5]), m[6] == null ? "-" : f2(m[6]), f2(m[7] * 100, 0) + "%"]);
const s9 = [
  H1("9. Results of the Reference Implementation"),
  callout("Reading the results", ["The data are simulated. These results validate the **pipeline and its safeguards**; they are not a claim about field accuracy. Every number below is produced by `python run_pipeline.py --scenario all` and stored in the outputs folder."], "FFF2E0", ACCENT),
  spacer(120),
  H2("9.1 Model comparison on the hidden test period"),
  tcap("Crop-yield scenario: test performance 2021-2023 (210 district-crop-years). RMSE and MAE in quintal/ha; the CV-selected champion is highlighted."),
  table(["Model", "RMSE", "MAE", "MAPE %", "R²", "Bias", "CV RMSE", "Skill"], mrows,
    [2750, 800, 800, 900, 800, 800, 1000, 1562], { align: [L, R, R, R, R, R, R, R], boldFirst: true, hi: [7] }),
  spacer(100),
  P(`All learned models beat all three baselines by a wide margin: the best baseline (3-period mean) has RMSE ${f2(D.crop_yield.models[1][1])} q/ha, versus ${f2(cyM.RMSE)} for the champion. The CV-selected ensemble (${cy.ensemble_members.join(" + ")}) has the lowest cross-validated error (${f2(cyM.CV_RMSE)}); on the test years the single Gradient Boosting model is marginally better (${f2(D.crop_yield.models[6][1])} versus ${f2(cyM.RMSE)}). This 2% difference is within noise and illustrates why selecting by CV, rather than by peeking at the test set, is the right discipline.`),
  ...cropFig("03_model_comparison.png", 580, "Hold-out test RMSE and R² for baselines (grey) and learned models (blue)."),
  ...cropFig("04_pred_vs_actual.png", 560, "Champion model: predicted versus actual yield on the test period (left) and distribution of errors (right)."),
  H2("9.2 Where does the model work well or poorly?"),
  table(["Crop", "RMSE (q/ha)", "MAPE %", "R² (within crop)"], D.by_crop.map(r => [r[0], f2(r[1]), f2(r[2], 1), f2(r[3])]), [2800, 2200, 2000, 2412], { align: [L, R, R, R], boldFirst: true }),
  tcap("Test error by crop."),
  P("Percentage errors are similar across crops (6.5-11%), with wheat highest. Within-crop R² is lower for cotton (0.34) and rice (0.44) because, inside one crop, yield varies less than across crops, so the same absolute error removes a smaller share of variance. For decision-making the relevant statistic is the percentage error, not pooled R²."),
  table(["Year", "RMSE (q/ha)", "R²", "Bias (q/ha)"], D.by_year.map(r => [String(r[0]), f2(r[1]), f2(r[2], 3), f2(r[3])]), [2300, 2400, 2300, 2412], { align: [L, R, R, R], boldFirst: true }),
  tcap("Test error by year."),
  P(`Errors are stable in 2021-2022 and rise in 2023, and the bias is consistently **negative**: the model under-forecasts by about ${f2(Math.abs(cyM.Bias))} q/ha (about 6% of the mean yield), more in 2023. District-level RMSE ranges from ${f2(D.dist[0][1])} q/ha (${D.dist[0][0]}) to ${f2(D.dist[D.dist.length - 1][1])} q/ha (${D.dist[D.dist.length - 1][0]}); the hardest districts are ${D.dist[D.dist.length - 1][0]} and ${D.dist[D.dist.length - 2][0]}.`),
  ...cropFig("08_error_by_group.png", 380, "Test RMSE by district."),
  H2("9.3 Uncertainty and calibration"),
  P(`The 90% conformal interval has half-width ${f2(cy.interval_halfwidth)} q/ha and contained **${f2(cy.interval_coverage_90 * 100, 1)}%** of test outcomes: close to, but below, the nominal 90%. The explanation is the persistent negative bias in the drifting test years; intervals built from 2017-2020 residuals do not anticipate a systematic shift. For the dairy scenario, where inputs are stable, coverage was ${f2(dm.interval_coverage_90 * 100, 1)}%. The practical remedy is periodic recalibration on the most recent seasons, adopted in Section 11.`),
  ...cropFig("07_intervals.png", 470, "Average forecast, actual and 90% conformal interval across the test years."),
  H2("9.4 What drives the predictions?"),
  table(["Feature", "Increase in RMSE when shuffled", "Std. dev."], D.crop_yield.imp.map(r => [r[0], f2(r[1]), f2(r[2])]), [4400, 3000, 2012], { align: [L, R, R], boldFirst: true }),
  tcap("Top permutation importances (crop-yield champion)."),
  P("Crop identity dominates, as expected. Next come the agronomically meaningful drivers: **maximum temperature at flowering**, the recent yield level, **sowing date**, **peak NDVI**, **nitrogen applied** and **variety type**. The ordering matches crop-physiology expectations and, importantly for adoption, it identifies levers a manager can act on (sowing date, fertiliser rate, variety)."),
  ...cropFig("05_importance.png", 400, "Permutation importance of the 15 most influential features."),
  H2("9.5 Which data sources are worth collecting? (ablation)"),
  table(["Feature group removed", "RMSE", "R²", "Change vs full model"], [["None (full model)", f2(cyM.RMSE), f2(cyM.R2, 3), "-"], ...D.crop_yield.ablation.map(r => [r[0], f2(r[1]), f2(r[2], 3), (r[1] - cyM.RMSE >= 0 ? "+" : "") + f2(r[1] - cyM.RMSE)])], [3200, 1700, 1700, 2812], { align: [L, R, R, R], boldFirst: true }),
  tcap("Feature-group ablation using the champion's hyperparameters (single-model refit)."),
  P("Removing **management** variables (+0.26 RMSE) or **remote sensing** (+0.15) hurts most. Removing weather, soil or identity changes error very little or even slightly improves it. This does not mean those variables are irrelevant: the information is **redundant** within the panel, since peak NDVI integrates the season's weather, soil properties are constant within a district so lagged yields already encode them, and one-hot district codes add variance. With only 19 seasons the model cannot separate such overlapping signals. The practical recommendation is to prioritise management records and satellite indices, and to re-run the ablation on real data before dropping any source, because real weather effects are usually weaker in NDVI than in simulation."),
  ...cropFig("06_ablation.png", 400, "Feature-group ablation: test RMSE after removing each group."),
  H2("9.6 Robustness: unseen districts and input drift"),
  P(`In leave-district-out cross-validation, where entire districts are hidden from training, the model achieved RMSE ${f2(cy.spatial_cv.RMSE)} q/ha and R² ${f2(cy.spatial_cv.R2, 3)} with near-zero bias, so it transfers to new locations, though this check does not control for time.`),
  table(["Feature", "PSI", "Status"], D.crop_yield.drift.map(r => [r[0], f2(r[1], 3), r[2]]), [4200, 2200, 3012], { align: [L, R, L], boldFirst: true }),
  tcap("Largest input shifts between development and test periods."),
  P("Mean temperature, thermal-time and irrigated fraction show **major** drift (PSI near 1.0), reflecting the simulated warming trend and irrigation expansion. This is the likely cause of the negative bias and of the slightly low interval coverage: trees cannot extrapolate beyond the training range. It demonstrates that the monitoring layer works as designed, and motivates the recommended remedies (trend-adjusted targets, annual retraining, recalibrated intervals)."),
];

// ---------- 10 Universality ----------
const dmRows = D.dairy_milk.models.map(m => [m[0], f2(m[1]), f2(m[2]), f2(m[3], 1), f2(m[4], 3), f2(m[7] * 100, 0) + "%"]);
const s10 = [
  H1("10. Universal Applicability Across Agribusiness Scenarios"),
  P("A key requirement of this task is that the approach should apply beyond one crop. The framework achieves this through **separation of concerns**: problem-specific knowledge is isolated in a small configuration and an optional domain-feature function, while splitting, tuning, benchmarking, uncertainty, explanation and monitoring are generic."),
  H2("10.1 The five-question adaptation recipe"),
  N("What is the **target** and in what unit? (yield, milk, price, demand, loss)", "recipe"),
  N("What is the **time index** and the forecast origin? (season, month, week)", "recipe"),
  N("What identifies an **entity** (district-crop, farm, mandi, warehouse, store)?", "recipe"),
  N("Which **feature groups** apply, and which domain index captures the main physical or economic mechanism?", "recipe"),
  N("Where does the **development period** end and what is the test horizon?", "recipe"),
  P("Answering these five questions defines a new Scenario; no change to the training, validation or evaluation code is needed."),
  tcap("Mapping of the framework to other agribusiness scenarios."),
  table(["Scenario", "Target", "Entity and time", "Typical features", "Domain index"], [
    ["Crop yield (demonstrated)", "Yield, q/ha", "District-crop, season", "Weather, soil, management, NDVI, lags", "Heat-stress degrees, water-supply index"],
    ["Dairy output (demonstrated)", "Litres/cow/day", "Farm, month", "Temperature, humidity, feed, lactation, herd", "Temperature-humidity index (THI)"],
    ["Mandi price forecasting", "Modal price, Rs/q", "Market-commodity, week", "Arrivals, rainfall, stocks, MSP, festival calendar", "Arrival-to-stock ratio"],
    ["Input demand (fertiliser, seed)", "Units sold", "Retailer-product, month", "Sowing progress, rainfall, crop prices, credit", "Price ratio crop/fertiliser"],
    ["Poultry and aquaculture", "Weight gain, mortality", "Shed or pond, week", "Feed, temperature, water quality", "Feed conversion ratio"],
    ["Post-harvest loss / cold chain", "Spoilage %", "Warehouse, week", "Temperature logs, humidity, dwell time", "Degree-hours above threshold"],
    ["Farm credit risk", "Default probability", "Borrower, season", "Yield forecast, price outlook, repayment history", "Expected margin per hectare"],
  ], [1900, 1400, 1800, 2500, 1812], { boldFirst: true, size: 16 }),
  H2("10.2 Evidence of transfer: dairy milk yield"),
  P(`To test the claim in practice, the identical pipeline was run on a different problem: forecasting monthly milk yield for ${D.dairy_milk.summary.rows / 60} farms over 60 months. Only the Scenario object and a THI-based feature function were written; models, split logic, tuning, intervals and diagnostics were reused unchanged.`),
  tcap("Dairy scenario: test performance, months 49-60 (480 farm-months). RMSE and MAE in litres/cow/day."),
  table(["Model", "RMSE", "MAE", "MAPE %", "R²", "Skill"], dmRows, [3300, 1100, 1100, 1300, 1100, 1512], { align: [L, R, R, R, R, R], boldFirst: true, hi: [7] }),
  spacer(100),
  P(`The conclusions mirror the crop case: every learned model beats the baselines, and the champion (${dm.champion}: ${dm.ensemble_members.join(" + ")}) reduces RMSE by ${f2(dm.skill_vs_naive * 100, 0)}% versus the naive forecast. Interval coverage was ${f2(dm.interval_coverage_90 * 100, 1)}% against a 90% target, and leave-farm-out R² was ${f2(dm.spatial_cv.R2, 3)}. The most important features (breed, previous-month yield, lactation-curve shape, heat-stress THI) are exactly those a dairy scientist would nominate, which supports the interpretability of the approach. In this scenario the linear model is competitive because the relationships are smoother, a reminder that the framework chooses among model families empirically instead of assuming one is best.`),
  ...dairyFig("04_pred_vs_actual.png", 520, "Dairy scenario: predicted versus actual milk yield and error distribution on the test period."),
  H2("10.3 Why the approach generalises"),
  B("**Model-agnostic:** any regressor with fit and predict can join the zoo."),
  B("**Schema-driven:** feature groups are declared, not hard-coded; the same ablation works for any grouping."),
  B("**Metric-agnostic validation:** chronological splitting, baselines and skill scores apply to any forecasting target."),
  B("**Uncertainty is generic:** conformal intervals need only residuals, not distributional assumptions."),
  B("**Scale-aware:** the same design extends from tens of farms to thousands of districts; models can be trained per region, per crop or globally with identity features."),
];

// ---------- 11 Deployment ----------
const s11 = [
  H1("11. Deployment, Monitoring and Governance"),
  H2("11.1 Operational workflow"),
  table(["Step", "Action", "Cadence"], [
    ["Ingest", "Load latest weather, NDVI and management data; run schema and range checks", "Weekly in season"],
    ["Forecast", "Load champion model; produce district forecast with 90% interval and top drivers", "Each forecast origin"],
    ["Monitor", "Compute PSI; compare realised yields with forecasts when available", "Each season"],
    ["Retrain", "Re-run the pipeline with the newest seasons; recalibrate conformal width", "Annually, or when PSI above 0.25"],
    ["Review", "Analyst signs off on metrics versus baseline before promoting a model", "Each retrain"],
  ], [1500, 5900, 2012], { boldFirst: true }),
  tcap("Proposed operating model."),
  H2("11.2 Governance and responsible use"),
  B("**Human in the loop:** forecasts support, not replace, extension officers' judgement; intervals communicate when to be cautious."),
  B("**Transparency:** permutation importance and ablation results are shared with users, so recommendations can be questioned."),
  B("**Fairness across regions:** per-district error tables are reviewed to ensure smaller or poorer districts are not systematically worse served."),
  B("**Data protection:** farm-level records contain personal and commercial information; they should be aggregated or anonymised and handled under applicable data-protection law."),
  B("**Reproducibility:** fixed seeds, versioned code and saved artefacts (model, metrics, predictions) make each forecast auditable."),
];

// ---------- 12 Limitations ----------
const s12 = [
  H1("12. Limitations and Future Work"),
  H2("12.1 Limitations"),
  B("**Simulated data.** Accuracy numbers reflect the simulator. Real data bring measurement error, reporting lags and unmodelled factors (pests, policy, input quality), so real accuracy will differ and must be established before operational use."),
  B("**Small test window.** Three test seasons give a noisy estimate; rolling-origin evaluation over more seasons would be more reliable."),
  B("**Under-forecasting under drift.** Tree ensembles do not extrapolate; bias grows when inputs trend beyond the training range."),
  B("**Redundant features.** With few seasons, weather, soil and identity features are partly interchangeable, which complicates attribution of importance."),
  B("**Association, not causation.** Permutation importance shows what the model uses, not what would happen if a lever were changed."),
  H2("12.2 Future work"),
  N("Validate on real district data (DES crop statistics, IMD rainfall, Soil Health Card, Sentinel-2 NDVI) and report results alongside the simulated benchmark.", "future"),
  N("Add trend-adjusted targets and a hierarchical model to improve extrapolation and small-district estimates.", "future"),
  N("Build staged forecast models for sowing, mid-season and pre-harvest origins to quantify the value of waiting for more data.", "future"),
  N("Introduce XGBoost or LightGBM and SHAP explanations for per-forecast attribution.", "future"),
  N("Link forecasts to optimisation (fertiliser, water, logistics) to quantify rupee value of improved accuracy.", "future"),
  N("Wrap the model in a lightweight API and dashboard for non-technical users.", "future"),
];

// ---------- 13 Conclusion ----------
const s13 = [
  H1("13. Conclusion"),
  P("This report has presented a complete predictive modelling framework for agricultural yield forecasting: a clear rationale rooted in resource-optimisation decisions, a justified catalogue of agronomic features, a leakage-free training process with chronological splitting and forward-chaining validation, a comparison of linear and ensemble algorithms with a practical path to more advanced models, and a multi-layered reliability programme covering baselines, calibrated uncertainty, explanation, ablation, spatial generalisation and drift detection."),
  P(`The accompanying implementation shows the framework working end to end. On simulated data it reduces forecasting error by ${f2(cy.skill_vs_naive * 100, 0)}% (crop yield) and ${f2(dm.skill_vs_naive * 100, 0)}% (dairy milk) over naive baselines, while honestly exposing its weaknesses, namely mild under-forecasting under input drift and slightly optimistic prediction intervals. Because problem-specific knowledge is confined to a small scenario definition, the same codebase serves other crops, livestock, price, demand and risk problems, which satisfies the requirement of universal applicability. The next step is to apply it to real regional data, where its built-in safeguards will help decide how far the forecasts can be trusted.`),
];

// ---------- references ----------
const refs = [
  "Breiman, L. (2001). Random forests. Machine Learning, 45(1), 5-32.",
  "Chen, T. and Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings of the 22nd ACM SIGKDD Conference, 785-794.",
  "Fisher, A., Rudin, C. and Dominici, F. (2019). All models are wrong, but many are useful: learning a variable's importance by studying an entire class of prediction models simultaneously. Journal of Machine Learning Research, 20(177), 1-81.",
  "Friedman, J. H. (2001). Greedy function approximation: a gradient boosting machine. Annals of Statistics, 29(5), 1189-1232.",
  "Geurts, P., Ernst, D. and Wehenkel, L. (2006). Extremely randomized trees. Machine Learning, 63(1), 3-42.",
  "Hoerl, A. E. and Kennard, R. W. (1970). Ridge regression: biased estimation for nonorthogonal problems. Technometrics, 12(1), 55-67.",
  "Hyndman, R. J. and Koehler, A. B. (2006). Another look at measures of forecast accuracy. International Journal of Forecasting, 22(4), 679-688.",
  "Ke, G. et al. (2017). LightGBM: A highly efficient gradient boosting decision tree. Advances in Neural Information Processing Systems 30.",
  "Lobell, D. B. and Burke, M. B. (2010). On the use of statistical models to predict crop yield responses to climate change. Agricultural and Forest Meteorology, 150(11), 1443-1452.",
  "Pedregosa, F. et al. (2011). Scikit-learn: Machine learning in Python. Journal of Machine Learning Research, 12, 2825-2830.",
  "van Klompenburg, T., Kassahun, A. and Catal, C. (2020). Crop yield prediction using machine learning: A systematic literature review. Computers and Electronics in Agriculture, 177, 105709.",
  "Vovk, V., Gammerman, A. and Shafer, G. (2005). Algorithmic Learning in a Random World. Springer.",
  "Bergmeir, C. and Benitez, J. M. (2012). On the use of cross-validation for time series predictor evaluation. Information Sciences, 191, 192-213.",
];
const sRefs = [
  H1p("References"),
  ...refs.map(r => new Paragraph({ spacing: { after: 100, line: 276 }, indent: { left: 480, hanging: 480 }, children: rich(r, { size: 20 }) })),
];

// ---------- appendix ----------
const sApp = [
  H1p("Appendix A. Project Structure and Reproduction Steps"),
  table(["Path", "Content"], [
    ["run_pipeline.py", "Command-line entry point (--scenario, --data, --n-iter, --seed)"],
    ["src/agriyield/", "config, data_generator, features, models, evaluate, plots, pipeline"],
    ["tests/test_framework.py", "Seven unit tests (no leakage, no look-ahead, metrics, conformal coverage, PSI)"],
    ["outputs/crop_yield, outputs/dairy_milk", "Datasets, metrics CSVs, predictions, figures, saved champion model, summary.json"],
    ["docs/", "Report generator, diagram script, figure files"],
    ["README.md, requirements.txt", "Documentation and dependencies"],
  ], [3300, 6112], { boldFirst: true, size: 18 }),
  tcap("Repository layout."),
  H3("Commands"),
  new Paragraph({ shading: { fill: "F2F4F6", type: ShadingType.CLEAR, color: "auto" }, spacing: { after: 40 }, children: [run("pip install -r requirements.txt", { font: "Consolas", size: 19 })] }),
  new Paragraph({ shading: { fill: "F2F4F6", type: ShadingType.CLEAR, color: "auto" }, spacing: { after: 40 }, children: [run("python run_pipeline.py --scenario all --n-iter 12", { font: "Consolas", size: 19 })] }),
  new Paragraph({ shading: { fill: "F2F4F6", type: ShadingType.CLEAR, color: "auto" }, spacing: { after: 40 }, children: [run("python run_pipeline.py --scenario crop_yield --data my_real_data.csv", { font: "Consolas", size: 19 })] }),
  new Paragraph({ shading: { fill: "F2F4F6", type: ShadingType.CLEAR, color: "auto" }, spacing: { after: 160 }, children: [run("python -m unittest discover -s tests", { font: "Consolas", size: 19 })] }),
  P("The complete run (both scenarios, 12 search iterations per model) takes roughly six minutes on a standard CPU. Random seeds are fixed, so numbers in this report can be reproduced exactly with the same library versions."),
];

// ---------- assemble ----------
const headStyle = (size, color, before, after) => ({ run: { size, bold: true, color, font: "Calibri" }, paragraph: { spacing: { before, after }, keepNext: true } });
const doc = new Document({
  creator: "Sumit Kumar Sharma", title: "Predictive Modeling Framework for Agricultural Yield Forecasting",
  description: "Week 4 task report", 
  styles: {
    default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(36, PRIMARY, 120, 200), paragraph: { spacing: { before: 120, after: 200 }, keepNext: true, outlineLevel: 0, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: ACCENT, space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(27, PRIMARY, 260, 120), paragraph: { spacing: { before: 260, after: 120 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(23, "33414A", 200, 100), paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 640, hanging: 300 } } } }, { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 1100, hanging: 300 } } } }] },
    ...["nums", "steps", "recipe", "future"].map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 640, hanging: 360 } } } }] })),
  ] },
  sections: [
    { properties: { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1247, bottom: 1247, left: MARGIN, right: MARGIN } } }, children: cover },
    { properties: { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1400, bottom: 1247, left: MARGIN, right: MARGIN }, pageNumbers: { start: 2 } } },
      headers: { default: new Header({ children: [new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BORDER, space: 4 } }, tabStops: [{ type: TabStopType.RIGHT, position: CW }],
        children: [run("Predictive Modeling Framework for Agricultural Yield Forecasting", { size: 17, color: GREY }), run("\tSumit Kumar Sharma", { size: 17, color: GREY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run("Page ", { size: 17, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], size: 17, color: GREY })] })] }) },
      children: [...tocBlock, ...s1, ...s2, ...s3, ...s4, ...s5, ...s6, ...s7, ...s8, ...s9, ...s10, ...s11, ...s12, ...s13, ...sRefs, ...sApp] },
  ],
});

const outFile = path.join(__dirname, "..", "Sumit_Kumar_Sharma_Predictive_Modeling_Framework.docx");
Packer.toBuffer(doc).then(b => { fs.writeFileSync(outFile, b); console.log("written", outFile, (b.length / 1024).toFixed(0) + " KB"); });
