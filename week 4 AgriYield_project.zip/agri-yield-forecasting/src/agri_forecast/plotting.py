"""Publication-quality figures with a single consistent style."""
from __future__ import annotations

from pathlib import Path
from typing import Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

GREEN, AMBER, BLUE, PURPLE, GRAY, RED = "#1B7F5C", "#D98A1F", "#2F6DB5", "#8A5CA8", "#6B7280", "#C0392B"
SEG_COLORS = [GREEN, AMBER, BLUE, PURPLE, RED, GRAY]
INK, GRID = "#1F2937", "#E5E7EB"

plt.rcParams.update({
    "figure.dpi": 150, "savefig.dpi": 200, "savefig.bbox": "tight",
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": "#9CA3AF",
    "axes.labelcolor": INK, "axes.titlecolor": INK, "axes.titlesize": 11.5, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.7, "xtick.color": INK, "ytick.color": INK, "legend.frameon": False,
})


def _save(fig, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)


# --------------------------------------------------------------------------- #
def plot_framework_diagram(path):
    """End-to-end pipeline schematic."""
    W = 14.0
    fig, ax = plt.subplots(figsize=(W, 5.2))
    ax.set_xlim(-0.3, W + 0.3)
    ax.set_ylim(-0.6, 4.8)
    ax.axis("off")
    ax.grid(False)
    stages = [
        ("1  Define", "Target, horizon,\nforecast origin,\nsuccess metric"),
        ("2  Data", "Weather, soil,\nmanagement,\nsatellite, history"),
        ("3  Features", "Lags, anomalies,\nstress indices,\nseasonality"),
        ("4  Split", "Temporal hold-out\n+ rolling-origin CV\n(no shuffling)"),
        ("5  Train", "Baselines, Ridge,\nRF, ET, GBM,\nensemble, tuning"),
        ("6  Evaluate", "RMSE, MAE, R2,\nskill vs baseline,\nbootstrap CIs"),
        ("7  Trust", "Intervals, drift,\nstress tests,\nablation"),
        ("8  Deploy", "Forecast service,\nmonitoring,\nretraining"),
    ]
    cols = [GREEN, GREEN, GREEN, BLUE, BLUE, AMBER, AMBER, PURPLE]
    n = len(stages)
    w, gap = 1.45, 0.34
    x0 = (W - (n * w + (n - 1) * gap)) / 2
    for i, ((t, d), c) in enumerate(zip(stages, cols)):
        x = x0 + i * (w + gap)
        ax.add_patch(FancyBboxPatch((x, 1.3), w, 2.4, boxstyle="round,pad=0.02,rounding_size=0.08",
                                    fc="white", ec=c, lw=1.8))
        ax.add_patch(FancyBboxPatch((x, 3.2), w, 0.5, boxstyle="round,pad=0.02,rounding_size=0.08",
                                    fc=c, ec=c, lw=1.8))
        ax.text(x + w / 2, 3.45, t, ha="center", va="center", color="white", fontsize=10, fontweight="bold")
        ax.text(x + w / 2, 2.2, d, ha="center", va="center", color=INK, fontsize=8.6, linespacing=1.5)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.03, 2.45), (x + w + gap - 0.03, 2.45),
                                         arrowstyle="-|>", mutation_scale=11, color=GRAY, lw=1.4))
    ax.add_patch(FancyArrowPatch((x0 + (n - 1) * (w + gap) + w / 2, 1.2), (x0 + w / 2, 1.2),
                                 connectionstyle="arc3,rad=-0.12", arrowstyle="-|>", mutation_scale=12,
                                 color=GRAY, lw=1.3, linestyle="--"))
    ax.text(W / 2, -0.45, "Monitoring feedback: drift or growing error triggers a data refresh and retraining",
            ha="center", color=GRAY, fontsize=9.5, style="italic")
    ax.text(W / 2, 4.5, "Scenario-agnostic predictive modeling pipeline", ha="center", fontsize=14,
            fontweight="bold", color=INK)
    _save(fig, path)


def plot_cv_scheme(path, periods, test_periods, n_folds, block):
    periods = list(periods)
    n = len(periods)
    fig, ax = plt.subplots(figsize=(9.5, 3.5))
    ax.grid(False)
    rows = n_folds + 1
    dev_n = n - test_periods
    for k in range(n_folds):
        end = dev_n - (n_folds - 1 - k) * block
        start = end - block
        y = rows - 1 - k
        ax.barh(y, start, left=0, color=BLUE, height=0.55, label="Train" if k == 0 else None)
        ax.barh(y, block, left=start, color=AMBER, height=0.55, label="Validate" if k == 0 else None)
        ax.text(-0.3, y, f"Fold {k + 1}", ha="right", va="center", fontsize=9)
    ax.barh(0, dev_n, color=BLUE, height=0.55)
    ax.barh(0, test_periods, left=dev_n, color=RED, height=0.55, label="Final hold-out test")
    ax.text(-0.3, 0, "Refit &\nTest", ha="right", va="center", fontsize=9)
    ax.set_yticks([])
    ax.set_xlim(0, n)
    ax.set_xticks(np.arange(0.5, n, max(1, n // 12)))
    ax.set_xticklabels([str(p) for p in periods][::max(1, n // 12)], fontsize=8)
    ax.set_xlabel("Time period (strictly chronological)")
    ax.set_title("Expanding-window cross-validation with a final untouched test block")
    ax.legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.22))
    ax.spines["left"].set_visible(False)
    _save(fig, path)


def plot_eda(df, cfg, path):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    ax = axes[0]
    if cfg.segment_col:
        for i, (seg, d) in enumerate(df.groupby(cfg.segment_col)):
            m = d.groupby(cfg.time_col)[cfg.target].mean()
            ax.plot(m.index, m.values, color=SEG_COLORS[i % 6], lw=1.8, label=str(seg))
        ax.legend(title=cfg.segment_col, fontsize=8, title_fontsize=8)
    else:
        m = df.groupby(cfg.time_col)[cfg.target].mean()
        ax.plot(m.index, m.values, color=GREEN, lw=1.8)
    ax.set_xlabel(cfg.time_col)
    ax.set_ylabel(f"Mean {cfg.target} ({cfg.target_unit})")
    ax.set_title("Target over time by segment")
    ax = axes[1]
    num = [c for c in df.select_dtypes("number").columns
           if c != cfg.target and not c.startswith(cfg.target) and c not in (cfg.time_col, "t_index")]
    corr = df[num].corrwith(df[cfg.target]).dropna()
    corr = corr.reindex(corr.abs().sort_values(ascending=False).index)[:12][::-1]
    ax.barh(corr.index, corr.values, color=[GREEN if v > 0 else RED for v in corr.values])
    ax.axvline(0, color=INK, lw=0.8)
    ax.set_xlabel("Pearson correlation with target")
    ax.set_title("Strongest linear associations (top 12)")
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    _save(fig, path)


def plot_model_comparison(table: pd.DataFrame, path, unit):
    t = table.sort_values("CV_RMSE", ascending=False)
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    y = np.arange(len(t))
    ax.barh(y + 0.19, t["CV_RMSE"], height=0.36, color=BLUE, label="Cross-validation RMSE (model selection)")
    ax.barh(y - 0.19, t["Test_RMSE"], height=0.36, color=GREEN, label="Final hold-out test RMSE")
    ax.set_yticks(y)
    ax.set_yticklabels(t["Model"])
    ax.set_xlabel(f"RMSE ({unit}), lower is better")
    ax.set_title("Model comparison")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=2, fontsize=8)
    ax.grid(axis="y", visible=False)
    for i, (a, b) in enumerate(zip(t["CV_RMSE"], t["Test_RMSE"])):
        ax.text(a, i + 0.19, f" {a:.3f}", va="center", fontsize=7.5)
        ax.text(b, i - 0.19, f" {b:.3f}", va="center", fontsize=7.5)
    _save(fig, path)


def plot_actual_vs_pred(test, cfg, path, pred_col="prediction"):
    fig, ax = plt.subplots(figsize=(5.6, 5.2))
    lo = min(test[cfg.target].min(), test[pred_col].min())
    hi = max(test[cfg.target].max(), test[pred_col].max())
    ax.plot([lo, hi], [lo, hi], color=GRAY, lw=1, ls="--", label="Perfect forecast")
    if cfg.segment_col:
        for i, (seg, d) in enumerate(test.groupby(cfg.segment_col)):
            ax.scatter(d[cfg.target], d[pred_col], s=16, alpha=0.75, color=SEG_COLORS[i % 6], label=str(seg), lw=0)
    else:
        ax.scatter(test[cfg.target], test[pred_col], s=16, alpha=0.75, color=GREEN, lw=0)
    ax.set_xlabel(f"Actual {cfg.target} ({cfg.target_unit})")
    ax.set_ylabel(f"Forecast ({cfg.target_unit})")
    ax.set_title("Hold-out test: forecast vs actual")
    ax.legend(fontsize=8)
    ax.set_aspect("equal", adjustable="datalim")
    _save(fig, path)


def plot_residuals(test, cfg, path, pred_col="prediction"):
    res = test[pred_col] - test[cfg.target]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    axes[0].hist(res, bins=30, color=BLUE, alpha=0.85, edgecolor="white")
    axes[0].axvline(0, color=INK, lw=1)
    axes[0].set_xlabel(f"Forecast error ({cfg.target_unit})")
    axes[0].set_ylabel("Count")
    axes[0].set_title("Error distribution")
    axes[1].scatter(test[pred_col], res, s=12, alpha=0.6, color=GREEN, lw=0)
    axes[1].axhline(0, color=INK, lw=1)
    axes[1].set_xlabel(f"Forecast ({cfg.target_unit})")
    axes[1].set_ylabel("Error")
    axes[1].set_title("Error vs forecast level (check for structure)")
    fig.tight_layout()
    _save(fig, path)


def plot_importance(group_imp: pd.DataFrame, path, unit):
    d = group_imp.sort_values("importance")
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.barh(d["feature"], d["importance"], xerr=d["std"], color=GREEN, error_kw=dict(ecolor=GRAY, lw=1))
    ax.set_xlabel(f"Increase in test RMSE when group is permuted ({unit})")
    ax.set_title("Feature-group importance (joint permutation)")
    ax.grid(axis="y", visible=False)
    _save(fig, path)


def plot_ablation(abl: pd.DataFrame, path, unit):
    d = abl.sort_values("delta_RMSE")
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.barh(d["dropped_group"], d["delta_RMSE"], color=[RED if v > 0 else GREEN for v in d["delta_RMSE"]])
    ax.axvline(0, color=INK, lw=0.8)
    ax.set_xlabel(f"Change in test RMSE after re-training without the group ({unit})")
    ax.set_title("Ablation: value of each feature group")
    ax.grid(axis="y", visible=False)
    _save(fig, path)


def plot_robustness(noise: pd.DataFrame, missing: pd.DataFrame, path, unit):
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    axes[0].plot(noise["noise_level"] * 100, noise["RMSE"], marker="o", color=AMBER, lw=2)
    axes[0].set_xlabel("Gaussian noise on inputs (% of feature SD)")
    axes[0].set_ylabel(f"Test RMSE ({unit})")
    axes[0].set_title("Sensitivity to measurement noise")
    axes[1].plot(missing["missing_rate"] * 100, missing["RMSE"], marker="o", color=PURPLE, lw=2)
    axes[1].set_xlabel("Randomly missing numeric inputs (%)")
    axes[1].set_ylabel(f"Test RMSE ({unit})")
    axes[1].set_title("Sensitivity to missing data")
    fig.tight_layout()
    _save(fig, path)


def plot_intervals(test, cfg, path, pred_col="prediction", n_series=3):
    sel = []
    if cfg.segment_col:
        for _, d in test.groupby(cfg.segment_col):
            gid = d.groupby(cfg.entity_cols).ngroup()
            sel.append(d[gid == gid.min()])      # first entity of each segment
    else:
        for _, d in list(test.groupby(cfg.entity_cols))[:n_series]:
            sel.append(d)
    sel = sel[:4]
    fig, axes = plt.subplots(1, len(sel), figsize=(3.6 * len(sel), 3.4), squeeze=False)
    for ax, d in zip(axes[0], sel):
        d = d.sort_values(cfg.time_col)
        ax.fill_between(d[cfg.time_col], d["lower"], d["upper"], color=BLUE, alpha=0.2, label="90 % interval")
        ax.plot(d[cfg.time_col], d[pred_col], color=BLUE, lw=1.8, marker="o", ms=3, label="Forecast")
        ax.plot(d[cfg.time_col], d[cfg.target], color=INK, lw=1.4, marker="s", ms=3, label="Actual")
        title = " / ".join(str(d.iloc[0][c]) for c in cfg.entity_cols)
        ax.set_title(title, fontsize=9.5)
        ax.set_xlabel(cfg.time_col)
        ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True, nbins=4))
        ax.tick_params(labelsize=8)
    axes[0][0].set_ylabel(f"{cfg.target_unit}")
    axes[0][0].legend(fontsize=7)
    fig.tight_layout()
    _save(fig, path)


def plot_scenario_comparison(summary: Dict[str, dict], path):
    names = list(summary)
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    sk = [summary[n]["skill_vs_naive"] * 100 for n in names]
    axes[0].bar(names, sk, color=[GREEN, AMBER][:len(names)])
    axes[0].set_ylabel("RMSE reduction vs naive baseline (%)")
    axes[0].set_title("Forecast skill, same code, different scenarios")
    axes[0].set_ylim(0, max(sk) * 1.18)
    axes[0].grid(axis="x", visible=False)
    for i, v in enumerate(sk):
        axes[0].text(i, v + 0.5, f"{v:.1f}%", ha="center", fontsize=9)
    cov = [summary[n]["interval_coverage"] * 100 for n in names]
    axes[1].bar(names, cov, color=[GREEN, AMBER][:len(names)])
    axes[1].axhline(90, color=RED, ls="--", lw=1.2)
    axes[1].set_ylim(0, 105)
    axes[1].set_ylabel("Empirical coverage of 90 % intervals (%)")
    axes[1].set_title("Interval calibration on hold-out data")
    axes[1].grid(axis="x", visible=False)
    for i, v in enumerate(cov):
        axes[1].text(i, v + 1.5, f"{v:.1f}%", ha="center", fontsize=9)
    fig.tight_layout()
    _save(fig, path)
