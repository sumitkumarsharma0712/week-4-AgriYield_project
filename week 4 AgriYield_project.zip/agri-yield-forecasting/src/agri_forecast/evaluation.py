"""Evaluation and reliability toolkit (all functions are scenario-agnostic)."""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------- #
# Point-forecast metrics
# --------------------------------------------------------------------------- #
def rmse(y, p) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def regression_metrics(y, p) -> Dict[str, float]:
    y, p = np.asarray(y, float), np.asarray(p, float)
    err = p - y
    ss_res, ss_tot = np.sum(err ** 2), np.sum((y - y.mean()) ** 2)
    return {
        "RMSE": float(np.sqrt(np.mean(err ** 2))),
        "MAE": float(np.mean(np.abs(err))),
        "MAPE_%": float(np.mean(np.abs(err) / np.clip(np.abs(y), 1e-9, None)) * 100),
        "R2": float(1 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
        "Bias": float(np.mean(err)),
        "RMSE_%_of_mean": float(np.sqrt(np.mean(err ** 2)) / y.mean() * 100),
    }


def skill_score(y, p, p_ref) -> float:
    """1 - RMSE_model / RMSE_reference. >0: better than the reference baseline."""
    return 1.0 - rmse(y, p) / rmse(y, p_ref)


def segment_metrics(df: pd.DataFrame, y_col: str, p_col: str, seg_col: str) -> pd.DataFrame:
    rows = []
    for seg, d in df.groupby(seg_col):
        m = regression_metrics(d[y_col], d[p_col])
        m[seg_col] = seg
        m["n"] = len(d)
        rows.append(m)
    cols = [seg_col, "n", "RMSE", "MAE", "MAPE_%", "R2", "Bias"]
    return pd.DataFrame(rows)[cols]


# --------------------------------------------------------------------------- #
# Uncertainty: entity-cluster bootstrap for metrics
# --------------------------------------------------------------------------- #
def cluster_bootstrap_rmse(y, preds: Dict[str, np.ndarray], clusters, n_boot: int = 2000, seed: int = 0,
                           ref: str | None = None) -> Dict[str, dict]:
    """Bootstrap RMSE (and skill vs ``ref``) by resampling whole entities, which respects
    the strong within-entity correlation of panel forecasts."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y, float)
    codes, uniq = pd.factorize(pd.Series(np.asarray(clusters)))
    k = len(uniq)
    n_c = np.bincount(codes, minlength=k).astype(float)
    se = {m: np.bincount(codes, weights=(np.asarray(p, float) - y) ** 2, minlength=k) for m, p in preds.items()}
    out = {m: [] for m in preds}
    skill = []
    for _ in range(n_boot):
        idx = rng.integers(0, k, k)
        tot = n_c[idx].sum()
        r = {m: np.sqrt(se[m][idx].sum() / tot) for m in preds}
        for m in preds:
            out[m].append(r[m])
        if ref is not None:
            skill.append({m: 1 - r[m] / r[ref] for m in preds})
    res = {}
    for m, v in out.items():
        lo, hi = np.percentile(v, [2.5, 97.5])
        res[m] = {"RMSE": rmse(y, preds[m]), "CI_low": float(lo), "CI_high": float(hi)}
        if ref is not None and m != ref:
            s = [d[m] for d in skill]
            res[m]["skill_vs_ref"] = float(1 - rmse(y, preds[m]) / rmse(y, preds[ref]))
            res[m]["skill_CI_low"], res[m]["skill_CI_high"] = [float(a) for a in np.percentile(s, [2.5, 97.5])]
    return res


# --------------------------------------------------------------------------- #
# Prediction intervals: (Mondrian) split-conformal from out-of-fold residuals
# --------------------------------------------------------------------------- #
def conformal_halfwidths(abs_res: np.ndarray, segments: np.ndarray | None, alpha: float,
                         min_seg: int = 30) -> Dict[str, float]:
    def q(a):
        n = len(a)
        level = min(1.0, np.ceil((n + 1) * (1 - alpha)) / n)
        return float(np.quantile(a, level, method="higher"))

    out = {"__global__": q(abs_res)}
    if segments is not None:
        for s in np.unique(segments):
            a = abs_res[segments == s]
            out[str(s)] = q(a) if len(a) >= min_seg else out["__global__"]
    return out


def apply_intervals(pred: np.ndarray, segments: np.ndarray | None, hw: Dict[str, float]):
    h = np.array([hw.get(str(s), hw["__global__"]) for s in segments]) if segments is not None \
        else np.full(len(pred), hw["__global__"])
    return pred - h, pred + h


def interval_report(y, lo, hi, segments=None) -> dict:
    y, lo, hi = map(np.asarray, (y, lo, hi))
    cov = (y >= lo) & (y <= hi)
    rep = {"coverage": float(cov.mean()), "mean_width": float((hi - lo).mean())}
    if segments is not None:
        rep["by_segment"] = {str(s): {"coverage": float(cov[segments == s].mean()),
                                      "mean_width": float((hi - lo)[segments == s].mean())}
                             for s in np.unique(segments)}
    return rep


# --------------------------------------------------------------------------- #
# Interpretability: grouped permutation importance
# --------------------------------------------------------------------------- #
def permutation_importance_groups(model, X: pd.DataFrame, y, groups: Dict[str, List[str]],
                                  n_repeats: int = 10, seed: int = 0) -> pd.DataFrame:
    """Increase in RMSE when the columns of a group are permuted jointly (same row shuffle).
    Joint permutation avoids the dilution that plagues correlated features."""
    rng = np.random.default_rng(seed)
    base = rmse(y, model.predict(X))
    rows = []
    for name, cols in groups.items():
        cols = [c for c in cols if c in X.columns]
        incs = []
        for _ in range(n_repeats):
            idx = rng.permutation(len(X))
            Xp = X.copy()
            Xp[cols] = X[cols].to_numpy()[idx]
            incs.append(rmse(y, model.predict(Xp)) - base)
        rows.append({"feature": name, "importance": float(np.mean(incs)), "std": float(np.std(incs)),
                     "n_cols": len(cols)})
    return pd.DataFrame(rows).sort_values("importance", ascending=False).reset_index(drop=True)


# --------------------------------------------------------------------------- #
# Reliability: drift, robustness to noise and to missing data
# --------------------------------------------------------------------------- #
def psi(reference: pd.Series, current: pd.Series, bins: int = 10) -> float:
    """Population Stability Index with reference-quantile bins."""
    ref, cur = reference.dropna().to_numpy(), current.dropna().to_numpy()
    edges = np.unique(np.quantile(ref, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    p = np.histogram(ref, edges)[0] / len(ref)
    q = np.histogram(cur, edges)[0] / len(cur)
    p, q = np.clip(p, 1e-4, None), np.clip(q, 1e-4, None)
    return float(np.sum((q - p) * np.log(q / p)))


def drift_table(dev: pd.DataFrame, test: pd.DataFrame, numeric: Sequence[str]) -> pd.DataFrame:
    rows = [{"feature": c, "PSI": psi(dev[c], test[c])} for c in numeric]
    d = pd.DataFrame(rows).sort_values("PSI", ascending=False).reset_index(drop=True)
    d["status"] = pd.cut(d["PSI"], [-1, 0.10, 0.25, np.inf], labels=["stable", "moderate shift", "major shift"])
    return d


def noise_robustness(model, X_test: pd.DataFrame, y_test, X_ref: pd.DataFrame, numeric: Sequence[str],
                     levels: Sequence[float] = (0.0, 0.05, 0.10, 0.20, 0.30), n_rep: int = 10, seed: int = 0) -> pd.DataFrame:
    """Add Gaussian noise (sd = level x training-sd) to every numeric input and track RMSE."""
    rng = np.random.default_rng(seed)
    sd = X_ref[list(numeric)].std()
    rows = []
    for lv in levels:
        vals = []
        for _ in range(n_rep if lv > 0 else 1):
            Xn = X_test.copy()
            Xn[list(numeric)] = Xn[list(numeric)] + rng.normal(0, 1, (len(Xn), len(numeric))) * (sd.to_numpy() * lv)
            vals.append(rmse(y_test, model.predict(Xn)))
        rows.append({"noise_level": lv, "RMSE": float(np.mean(vals))})
    return pd.DataFrame(rows)


def missing_robustness(model, X_test: pd.DataFrame, y_test, numeric: Sequence[str],
                       rates: Sequence[float] = (0.0, 0.10, 0.20, 0.30, 0.50), n_rep: int = 10, seed: int = 0) -> pd.DataFrame:
    """Randomly blank out a share of numeric inputs (sensor outage / late data) and track RMSE."""
    rng = np.random.default_rng(seed)
    rows = []
    for r in rates:
        vals = []
        for _ in range(n_rep if r > 0 else 1):
            Xm = X_test.copy()
            mask = rng.random((len(Xm), len(numeric))) < r
            block = Xm[list(numeric)].to_numpy(dtype=float)
            block[mask] = np.nan
            Xm[list(numeric)] = block
            vals.append(rmse(y_test, model.predict(Xm)))
        rows.append({"missing_rate": r, "RMSE": float(np.mean(vals))})
    return pd.DataFrame(rows)


def residual_diagnostics(df: pd.DataFrame, y_col: str, p_col: str, entity_cols: List[str], time_col: str) -> dict:
    res = df[p_col] - df[y_col]
    d = df.assign(_res=res).sort_values(entity_cols + [time_col])
    ac = d.groupby(entity_cols)["_res"].apply(lambda s: s.autocorr(1) if len(s) > 2 else np.nan)
    return {
        "residual_mean": float(res.mean()),
        "residual_std": float(res.std()),
        "heteroscedasticity_corr(|res|,pred)": float(np.corrcoef(res.abs(), df[p_col])[0, 1]),
        "mean_lag1_autocorr_by_entity": float(np.nanmean(ac)),
        "share_abs_err_gt_2sd_%": float((res.abs() > 2 * res.std()).mean() * 100),
    }
