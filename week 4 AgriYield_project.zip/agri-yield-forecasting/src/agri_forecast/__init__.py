"""Scenario-agnostic predictive modeling framework for agribusiness forecasting."""

__version__ = "1.0.0"
