"""Model zoo, preprocessing and time-aware cross-validation."""
from __future__ import annotations
from typing import Dict, Iterator, List, Tuple
import numpy as np
import pandas as pd
from scipy.stats import loguniform, randint, uniform
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import (ExtraTreesRegressor, HistGradientBoostingRegressor,
                              RandomForestRegressor, VotingRegressor)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def make_preprocessor(num_cols: List[str], cat_cols: List[str], scale: bool) -> ColumnTransformer:
    num_steps = [("impute", SimpleImputer(strategy="median", add_indicator=False))]
    if scale:
        num_steps.append(("scale", StandardScaler()))
    return ColumnTransformer([
        ("num", Pipeline(num_steps), num_cols),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), cat_cols),
    ])


def model_zoo(seed: int = 42) -> Dict[str, Tuple[object, dict, bool]]:
    """name -> (estimator, search space, needs_scaling)."""
    return {
        "Ridge": (Ridge(), {"alpha": loguniform(1e-2, 1e2)}, True),
        "RandomForest": (RandomForestRegressor(n_estimators=300, n_jobs=-1, random_state=seed),
                         {"max_depth": [6, 10, 14, None], "min_samples_leaf": randint(1, 8),
                          "max_features": uniform(0.3, 0.6)}, False),
        "ExtraTrees": (ExtraTreesRegressor(n_estimators=300, n_jobs=-1, random_state=seed),
                       {"max_depth": [8, 12, None], "min_samples_leaf": randint(1, 6),
                        "max_features": uniform(0.4, 0.55)}, False),
        "GradientBoosting": (HistGradientBoostingRegressor(random_state=seed, early_stopping=False),
                             {"learning_rate": loguniform(0.02, 0.2), "max_iter": randint(150, 600),
                              "max_depth": [3, 4, 6, None], "min_samples_leaf": randint(5, 40),
                              "l2_regularization": loguniform(1e-3, 10)}, False),
    }


class ExpandingWindowSplit:
    """Forward-chaining CV: every validation block lies strictly after its training data."""

    def __init__(self, times: np.ndarray, n_folds: int, block: int, dev_mask: np.ndarray | None = None):
        self.times = np.asarray(times)
        self.dev = np.ones(len(times), bool) if dev_mask is None else np.asarray(dev_mask)
        periods = np.sort(np.unique(self.times[self.dev]))
        tail = periods[-n_folds * block:]
        self.blocks = [tail[i * block:(i + 1) * block] for i in range(n_folds)]

    def split(self, X=None, y=None, groups=None) -> Iterator[Tuple[np.ndarray, np.ndarray]]:
        for b in self.blocks:
            tr = np.where(self.dev & (self.times < b.min()))[0]
            va = np.where(self.dev & np.isin(self.times, b))[0]
            yield tr, va

    def get_n_splits(self, *a, **k):
        return len(self.blocks)


def tune_model(name, est, space, scale, num_cols, cat_cols, X, y, cv, n_iter=15, seed=42):
    pipe = Pipeline([("prep", make_preprocessor(num_cols, cat_cols, scale)), ("model", est)])
    grid = {f"model__{k}": v for k, v in space.items()}
    search = RandomizedSearchCV(pipe, grid, n_iter=n_iter, cv=list(cv.split()), random_state=seed,
                                scoring="neg_root_mean_squared_error", n_jobs=1, refit=False)
    search.fit(X, y)
    best = {k.replace("model__", ""): v for k, v in search.best_params_.items()}
    cv_rmse = -search.best_score_
    return best, cv_rmse


def build_pipeline(est, scale, num_cols, cat_cols, params=None):
    from sklearn.base import clone
    est = clone(est)
    if params:
        est.set_params(**params)
    return Pipeline([("prep", make_preprocessor(num_cols, cat_cols, scale)), ("model", est)])


def build_ensemble(pipes: Dict[str, Pipeline], weights=None):
    return VotingRegressor([(k, v) for k, v in pipes.items()], weights=weights)
