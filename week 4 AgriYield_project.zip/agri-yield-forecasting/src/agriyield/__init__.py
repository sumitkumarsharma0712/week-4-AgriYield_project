"""AgriYield: a scenario-agnostic predictive modelling framework for agribusiness."""
__version__ = "1.0.0"
