"""Metrics, uncertainty quantification and drift diagnostics."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def regression_metrics(y, p) -> dict:
    y, p = np.asarray(y, float), np.asarray(p, float)
    mape = np.mean(np.abs((y - p) / np.clip(np.abs(y), 1e-6, None))) * 100
    smape = np.mean(2 * np.abs(y - p) / (np.abs(y) + np.abs(p) + 1e-9)) * 100
    return dict(RMSE=float(np.sqrt(mean_squared_error(y, p))), MAE=float(mean_absolute_error(y, p)),
                MAPE=float(mape), sMAPE=float(smape), R2=float(r2_score(y, p)), Bias=float(np.mean(p - y)))


def skill_score(rmse_model: float, rmse_baseline: float) -> float:
    """1 - RMSE/RMSE_baseline. > 0 means the model beats the baseline."""
    return 1 - rmse_model / rmse_baseline


def metrics_by(df: pd.DataFrame, by: str, y="y_true", p="y_pred") -> pd.DataFrame:
    rows = []
    for k, g in df.groupby(by):
        m = regression_metrics(g[y], g[p]); m[by] = k; m["n"] = len(g)
        rows.append(m)
    return pd.DataFrame(rows).set_index(by)


def conformal_interval(oof_residuals: np.ndarray, pred: np.ndarray, alpha: float = 0.10):
    """Split-conformal prediction interval from out-of-fold absolute residuals."""
    r = np.abs(np.asarray(oof_residuals))
    n = len(r)
    q = np.quantile(r, min(1.0, np.ceil((n + 1) * (1 - alpha)) / n))
    return pred - q, pred + q, float(q)


def interval_coverage(y, lo, hi) -> float:
    y = np.asarray(y)
    return float(np.mean((y >= lo) & (y <= hi)))


def psi(expected: pd.Series, actual: pd.Series, bins: int = 10) -> float:
    """Population Stability Index between training and new data (drift monitor)."""
    e, a = expected.dropna().values, actual.dropna().values
    edges = np.unique(np.quantile(e, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    pe = np.histogram(e, edges)[0] / len(e) + 1e-4
    pa = np.histogram(a, edges)[0] / len(a) + 1e-4
    return float(np.sum((pa - pe) * np.log(pa / pe)))


def drift_table(train: pd.DataFrame, test: pd.DataFrame, cols) -> pd.DataFrame:
    rows = [(c, psi(train[c], test[c])) for c in cols]
    out = pd.DataFrame(rows, columns=["feature", "PSI"]).sort_values("PSI", ascending=False)
    out["status"] = pd.cut(out["PSI"], [-1, .1, .25, 1e9], labels=["stable", "moderate shift", "major shift"])
    return out.reset_index(drop=True)
